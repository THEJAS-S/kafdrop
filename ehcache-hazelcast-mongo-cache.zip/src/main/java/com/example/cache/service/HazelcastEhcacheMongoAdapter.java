package com.example.cache.service;

import com.example.cache.model.KeyValueDocument;
import com.example.cache.repository.KeyValueRepository;
import com.hazelcast.map.IMap;
import org.ehcache.Cache;

import java.util.Optional;

public class HazelcastEhcacheMongoAdapter implements DistributedCache<String, String> {

    private final Cache<String, String> ehCache;
    private final IMap<String, String> hzMap;
    private final KeyValueRepository mongoRepo;

    public HazelcastEhcacheMongoAdapter(Cache<String, String> ehCache,
                                        IMap<String, String> hzMap,
                                        KeyValueRepository mongoRepo) {
        this.ehCache = ehCache;
        this.hzMap = hzMap;
        this.mongoRepo = mongoRepo;
    }

    @Override
    public String get(String key) {
        String value = ehCache.get(key);
        if (value != null) return value;

        value = hzMap.get(key);
        if (value != null) {
            ehCache.put(key, value);
            return value;
        }

        Optional<KeyValueDocument> doc = mongoRepo.findById(key);
        if (doc.isPresent()) {
            value = doc.get().getValue();
            hzMap.put(key, value);
            ehCache.put(key, value);
        }

        return value;
    }

    @Override
    public void put(String key, String value) {
        ehCache.put(key, value);
        hzMap.put(key, value);
        mongoRepo.save(new KeyValueDocument(key, value));
    }

    @Override
    public void evict(String key) {
        ehCache.remove(key);
        hzMap.remove(key);
        mongoRepo.deleteById(key);
    }
}
