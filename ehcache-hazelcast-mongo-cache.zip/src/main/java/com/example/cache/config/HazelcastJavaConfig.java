package com.example.cache.config;

import com.hazelcast.config.*;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HazelcastJavaConfig {

    @Bean
    public HazelcastInstance hazelcastInstance() {
        Config config = new Config();

        config.setClusterName("my-cluster");

        // Network Config
        NetworkConfig networkConfig = config.getNetworkConfig();
        networkConfig.setPort(5701).setPortAutoIncrement(true);
        JoinConfig joinConfig = networkConfig.getJoin();
        joinConfig.getMulticastConfig().setEnabled(false);

        joinConfig.getTcpIpConfig()
                .setEnabled(true)
                .addMember("127.0.0.1"); // or IPs of other cluster members

        // Map Configuration
        MapConfig mapConfig = new MapConfig();
        mapConfig.setName("my-distributed-cache");
        mapConfig.setTimeToLiveSeconds(300); // 5 minutes TTL
        mapConfig.setMaxIdleSeconds(0);      // Optional: idle eviction

        config.addMapConfig(mapConfig);

        return Hazelcast.newHazelcastInstance(config);
    }
}
