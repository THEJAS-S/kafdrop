package com.example.cache.config;

import com.example.cache.repository.KeyValueRepository;
import com.example.cache.service.DistributedCache;
import com.example.cache.service.HazelcastEhcacheMongoAdapter;
import com.hazelcast.config.Config;
import com.hazelcast.config.MapConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import org.ehcache.Cache;
import org.ehcache.CacheManager;
import org.ehcache.config.builders.*;
import org.ehcache.expiry.ExpiryPolicyBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

@Configuration
public class CacheConfig {

    @Bean
    public CacheManager ehcacheManager() {
        return CacheManagerBuilder.newCacheManagerBuilder()
                .withCache("localCache",
                        CacheConfigurationBuilder.newCacheConfigurationBuilder(
                                String.class, String.class,
                                ResourcePoolsBuilder.heap(1000))
                                .withExpiry(ExpiryPolicyBuilder.timeToLiveExpiration(Duration.ofMinutes(5)))
                ).build(true);
    }

    @Bean
    public HazelcastInstance hazelcastInstance() {
        Config config = new Config();
        config.setClusterName("my-cluster");
        config.addMapConfig(new MapConfig("my-distributed-cache")
                .setTimeToLiveSeconds(300));
        return Hazelcast.newHazelcastInstance(config);
    }

    @Bean
    public DistributedCache<String, String> distributedCache(
            CacheManager ehcacheManager,
            HazelcastInstance hazelcastInstance,
            KeyValueRepository mongoRepo
    ) {
        Cache<String, String> ehcache = ehcacheManager.getCache("localCache", String.class, String.class);
        IMap<String, String> hazelcastMap = hazelcastInstance.getMap("my-distributed-cache");
        return new HazelcastEhcacheMongoAdapter(ehcache, hazelcastMap, mongoRepo);
    }
}
