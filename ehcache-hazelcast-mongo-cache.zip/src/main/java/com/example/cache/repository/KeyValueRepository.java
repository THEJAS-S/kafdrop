package com.example.cache.repository;

import com.example.cache.model.KeyValueDocument;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface KeyValueRepository extends MongoRepository<KeyValueDocument, String> {}
