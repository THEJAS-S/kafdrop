package com.example.cache.controller;

import com.example.cache.service.DistributedCache;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cache")
public class CacheController {

    private final DistributedCache<String, String> cache;

    public CacheController(DistributedCache<String, String> cache) {
        this.cache = cache;
    }

    @GetMapping("/{key}")
    public String get(@PathVariable String key) {
        return cache.get(key);
    }

    @PostMapping("/{key}")
    public void put(@PathVariable String key, @RequestBody String value) {
        cache.put(key, value);
    }

    @DeleteMapping("/{key}")
    public void delete(@PathVariable String key) {
        cache.evict(key);
    }
}
